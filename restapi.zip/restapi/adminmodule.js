var express = require('express');
var promise = require('bluebird');
var bodyparser = require('body-parser');
var options = {
    promiseLib: promise
};
var pgp = require('pg-promise')(options);
//var router = express.Router();

var fs = require('fs');
var path = require('path');

var router = express();

router.use(bodyparser.urlencoded({limit:'20mb',extended: true }));
router.use(bodyparser.json({limit:'20mb',extended: true }));
var constring1 = 'postgres://postgres:root@192.168.0.129:5432/GetSurv';

router.get('/package', (req, res, next) => {
    var mydb = pgp(constring1);
    mydb.any('select fn_getpackageDetails() ').then((data) => {
        res.send(data);
    })
    pgp.end();
})

router.get('/package/:id', (req, res, next) => {
    id = req.params.id
    var mydb = pgp(constring1);
    mydb.any('select fn_getPackageById($1)', id).then((data) => {
        res.send(data);
    })
    pgp.end();
})
router.post('/package', (req, res, next) => {
    pkgname = req.body.pckname;
    pdurtn = req.body.pckduration;
    pprc = req.body.pckprice;
    pdesc = req.body.pckdescription;

    var mydb = pgp(constring1);
    mydb.any('select fn_addPackage($1,$2,$3,$4)',
        [pkgname, pdurtn, pprc, pdesc]).then((data) => {
            res.send({ message: "Record Inserted Succexxx.." });
        })
    pgp.end();
})

router.delete('/package/:id', (req, res, next) => {
    id = req.params.id
    var mydb = pgp(constring1);
    mydb.any('select fn_delPackageDetails($1)', id).then((data) => {
        res.send({ "message": "Recorded Deleted...." });
    })
    pgp.end();
})

router.put('/package/:pckid', (req, res, next) => {
    pid = req.params.pckid;
    pkname = req.body.pckname;
    pdurtn = req.body.pckduration;
    pprc = req.body.pckprice;
    pdesc = req.body.pckdescription;

    var mydb = pgp(constring1);
    mydb.any('select fn_updPackage($1,$2,$3,$4,$5)',
        [pid, pkname, pdurtn, pprc, pdesc]).then((data) => {
            res.send({ "message": "upted sucessfully...." })
        })
    pgp.end();
})

router.get('/offer', (req, res, next) => {
    var mydb = pgp(constring1)
    mydb.any("select fn_getPackageOfferDetails()").then((data) => {
        res.send(data)
    })
    pgp.end();
})



router.post('/offer', (req, res, next) => {
    var mydb = pgp(constring1);
    console.log(req.body)
    offrid = req.body.offerid;
    offrname = req.body.offername;
    discnt = req.body.discount;
    mydb.any('select fn_addPackageOffer($1,$2,$3)',
        [offrid, offrname, discnt]).then((data) => {
            res.send({ 'message': 'insert successsfull' })
        })
    pgp.end();
})

router.put('/offer/:offerid', (req, res, next) => {
    offrid = req.params.offerid;
    offrname = req.body.offername;
    discnt = req.body.discount;
    var mydb = pgp(constring1)
    mydb.any('select fn_updPackageOffer($1,$2,$3)', [offrid, offrname, discnt]).then((data) => {
        res.send({ 'message': 'updated successsfully' })
    })
    pgp.end();
})
router.delete('/offer/:offerid', (req, res, next) => {
    offrid = req.params.offerid
    var mydb = pgp(constring1)
    mydb.any('select fn_delPackageOffer($1)', offrid).then((data) => {
        res.send({ 'message': 'deleted successfully' })
    })
    pgp.end();
})
router.get('/offer/:offerid', (req, res, next) => {
    offrid = req.params.offerid
    var mydb = pgp(constring1)
    mydb.any('select fn_getPackageOfferById($1)', offrid).then((data) => {
        res.send(data)
    })
    pgp.end();
})

router.get('/adm/:uname/:pwd', (req, res, next) => {
    var uname = req.params.uname;
    var pwd = req.params.pwd;
    var mydb = pgp(constring1)
    mydb.any('select fn_adminLogin($1,$2)',[uname,pwd]).then((data) => {
        res.send(data)
    })
    pgp.end();
})

module.exports = router