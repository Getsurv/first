var fs = require('fs')
var path = require('path')
var express = require('express')
var promise = require('bluebird')
var bodyparser = require('body-parser')
var router = express.Router()
var option = {
    promiseLib: promise
};
var pgp = require('pg-promise')(option)

router.use(bodyparser.urlencoded({limit:'20mb',extended: true }))
router.use(bodyparser.json({limit:'20mb',extended: true }))
var constring1 = 'postgres://postgres:root@192.168.0.129:5432/GetSurv';
router.get('/cli', (req, res, next) => {
    var mydb = pgp(constring1);
    mydb.any('select fn_getclientfrim() ').then((data) => {

        res.send(data);
    })
    pgp.end();
})

router.get('/cli/:id', (req, res, next) => {
    id = req.params.id
    var mydb = pgp(constring1);
    mydb.any('select fn_getClientFrimById($1)', id).then((data) => {
        res.send(data);
    })
    pgp.end();
})

router.post('/cli', (req, res, next) => {
    ci = userid;
    //cid = req.body.clientid;
    frname = req.body.firmname;
    estbyear = req.body.establishedyear;
    descptn = req.body.description;
    pfirm = req.body.parentfirm;
    adrs = req.body.address;
    cty = req.body.city;
    stte = req.body.state;
    cntry = req.body.country;
    zpcode = req.body.zipcode;

    var mydb = pgp(constring1);
    mydb.any('select fn_addCfirm($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',
        [ci, frname, estbyear, descptn, pfirm, adrs, cty, stte, cntry, zpcode]).then((data) => {
            res.send({ message: "Record Inserted Succexxx.." });
        })
    pgp.end(); 
})

router.put('/cli/:clientid', (req, res, next) => {
    cid = req.params.clientid;
    frname = req.body.firmname;
    descptn = req.body.description;
    adrs = req.body.address;
    cty = req.body.city;
    stte = req.body.state;
    cntry = req.body.country;
    zpcode = req.body.zipcode;

    var mydb = pgp(constring1);
    mydb.any('select fn_updCfirm($1,$2,$3,$4,$5,$6,$7,$8)',
        [cid, frname, descptn, adrs, cty, stte, cntry, zpcode]).then((data) => {
            res.send({ "message": "upted sucessfully...." })
        })
    pgp.end();
})
router.post('/user', (req, res, next) => {
    var fname = req.body.firstname;
    var lname = req.body.lastname;
    var eid = req.body.emailid
    var pwd = req.body.password
    var mno = req.body.mobileno
    var gen = req.body.gender
    var adrs = req.body.address
    var cntry = req.body.country;
    var ste = req.body.state;
    var cty = req.body.city;
    var zcode = req.body.zipcode;
    var typ = req.body.typeofuser;
    var img = req.body.image;
    var myDb = pgp(cs)

    myDb.any("select fn_userAdd($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)", [fname, lname, eid, pwd, mno, gen, adrs, cntry, ste, cty, zcode, typ]).then((data) => {
        res.send({ "message": "inserted succesfully" })
        console.log(data)
        global.userid=data[0].fn_useradd;
           var fn = userid+'.png';
           console.log(fn)
           fs.writeFile(path.join(__dirname, 'pics/' + fn),
               img,'base64',(err) => {
               });
    })
    pgp.end()
})
module.exports = router