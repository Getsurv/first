var fs = require('fs')
var path = require('path')
var express = require('express')
var promise = require('bluebird')
var bodyparser = require('body-parser')
var router = express.Router()
var option = {
    promiseLib: promise
};
var pgp = require('pg-promise')(option)

router.use(bodyparser.urlencoded({limit:'20mb',extended: true }))
router.use(bodyparser.json({limit:'20mb',extended: true }))
var constring1 = 'postgres://postgres:root@192.168.0.129:5432/GetSurv';

router.get('/user', (req, res, next) => {
    var myDb = pgp(constring1)
    myDb.any('select fn_getAll()').then((data) => {
        res.send(data)
    })
    pgp.end()
})

router.get('/user/:id', (req, res, next) => {
    var id = req.params.id
    var myDb = pgp(constring1)
    myDb.any('select fn_getByEmail($1)', id).then((data) => {
        res.send(data)
    })
    pgp.end()
})
router.get('/user/login/:id/:ip', (req, res, next) => {
    var id = req.params.id;
    var ip = req.params.ip;
    var myDb = pgp(constring1)
    myDb.any('select fn_userLogin($1,$2)', [id, ip]).then((data) => {
        res.send(data)
    })
    pgp.end()
})

router.put('/user/:emailid', (req, res, next) => {
    var eid = req.params.emailid
    var pwd = req.body.password
    var myDb = pgp(constring1)
    myDb.any("select fn_changePwd($1,$2)", [eid, pwd]).then((data) => {
        res.send({ "message": "updated succesfully" })
    })
    pgp.end()
})

router.post('/user', (req, res, next) => {
    var fname = req.body.firstname;
    var lname = req.body.lastname;
    var eid = req.body.emailid
    var pwd = req.body.password
    var mno = req.body.mobileno
    var gen = req.body.gender
    var adrs = req.body.address
    var cntry = req.body.country;
    var stte = req.body.state;
    var cty = req.body.city;
    var zpcode = req.body.zipcode;
    var usrtyp = req.body.typeofuser;
    var img = req.body.image;
    var myDb = pgp(constring1)
    myDb.any("select fn_userAdd($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)", [fname, lname, eid, pwd, mno, gen, adrs, cntry, stte, cty, zpcode, usrtyp]).then((data) => {
        res.send({ "message": "inserted succesfully" })
        console.log(data)
        var userid=data[0].fn_useradd;
           var fn = userid+'.png';
           console.log(fn)
           fs.writeFile(path.join(__dirname, 'pics/' + fn),
               img,'base64',(err) => {
               });
    })
    pgp.end()
})

router.put('/user/update/:emailid', (req, res, next) => {
    var eid = req.params.emailid
    var fname = req.body.firstname;
    var lname = req.body.lastname;
    var mno = req.body.mobileno;
    var adrs = req.body.address;
    var cntry = req.body.country;
    var stte = req.body.state;
    var cty = req.body.city;
    var zpcode = req.body.zipcode;
    var myDb = pgp(constring1)
    myDb.any("select fn_userUpdate($1,$2,$3,$4,$5,$6,$7,$8,$9)", [fname, lname, mno, adrs, cntry, stte, cty, zpcode, eid]).then((data) => {
        res.send({ "message": "updated succesfully" })
    })
    pgp.end()
})
router.get('/r/w/e/rewards/:userid', (req, res, next) => {
    var id = req.params.userid;
    myDb = pgp(constring1)
    myDb.any('select fn_getrewards($1)', id).then((data) => {
        res.send(data);
    })
    pgp.end()
})
router.post('/feed',(req,res,next)=>{
    var nme=req.body.name;
    var eid=req.body.emailid;
    var rate=req.body.rating;
    var revew=req.body.review;
   var myDb=pgp(constring1)
   myDb.any("select fn_feedback($1,$2,$3,$4)",[nme,eid,rate,revew]).then((data)=>{
       res.send({"message":"inserted succesfully"})
   })
   pgp.end()
})
router.get('/getdetails',(req,res,next)=>{
    var myDb=pgp(constring1)
    myDb.any('select fn_getFeedBack()').then((data)=>{
        res.send(data)
    })
    pgp.end()
})

module.exports = router