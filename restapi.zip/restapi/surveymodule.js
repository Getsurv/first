var fs = require('fs')
var path = require('path')
var express = require('express')
var promise = require('bluebird')
var bodyparser = require('body-parser')
var router = express.Router()
var option = {
    promiseLib: promise
};
var pgp = require('pg-promise')(option)

router.use(bodyparser.urlencoded({limit:'20mb',extended: true }))
router.use(bodyparser.json({limit:'20mb',extended: true }))
var constring = 'postgres://postgres:root@localhost:5432/GetSurv'
var constring1 = 'postgres://postgres:root@192.168.0.129:5432/GetSurv';

router.get('/questions', (req, res, next) => {
    var db = pgp(constring);
    db.any('select fn_getQuestions()').then((data) => {
        res.send(data)
    })
    pgp.end();
})


router.get('/questions/:qid', (req, res, next) => {
    var id = req.params.qid;
    var db = pgp(constring);
    db.any('select fn_getById_Questions($1)', id).then((data) => {
        res.send(data);
    })
    pgp.end();
})

router.get('/questions/sta/:type', (req, res, next) => {
    var typ = req.params.type;
    var db = pgp(constring);
    db.any('select fn_getByStatus_Questions($1)', typ).then((data) => {
        res.send(data);
    })
    pgp.end(); 
})

router.post('/questions', (req, res, next) => {
    //var qid=req.body.questionId;
    var que = req.body.question;
    var cid = req.body.clientId;
    var quetyp = req.body.questionType;
    var quemod=req.body.questionmodel
    var db = pgp(constring);
    db.any('select fn_addQuestions($1,$2,$3,$4)', [que, cid, quetyp,quemod]).then((data) => {
        res.send({ message: " inserted succesfully...." })
    })
    pgp.end();
})
router.put('/questions/:questionid', (req, res, next) => {
    var qid = req.params.questionid;
    var que = req.body.question;
   

    var db = pgp(constring);
    db.any('select fn_updQuestions($1,$2)', [que, qid]).then((data) => {
        res.send({ message: "updated succesfully...." })
    })
    pgp.end();
})

router.get('/survey', (req, res, next) => {
    var mydb = pgp(constring1);
    mydb.any('select fn_getSurveyDetails()').then((data) => {
        res.send(data);
    })
    pgp.end();
})
router.get('/survey/:id', (req, res, next) => {
    id = req.params.id
    var mydb = pgp(constring1);
    mydb.any('select fn_getSurveyDetailsById($1)', id).then((data) => {
        res.send(data);
    })
    pgp.end();
})
router.post('/survey', (req, res, next) => {
    sname = req.body.surveyname;
    cid = req.body.clientid;
    sdate = req.body.startingdate;
    edate = req.body.endingdate;
    sta = req.body.status;
    rwd = req.body.rewards;
    var mydb = pgp(constring1);
    mydb.any('select fn_addSurvey($1,$2,$3,$4,$5,$6)',
        [sname, cid, sdate, edate, sta, rwd]).then((data) => {
            res.send({ message: "Record Inserted Succexxx.." });
        })
    pgp.end();
})

router.delete('/survey/:id', (req, res, next) => {
    id = req.params.id
    var mydb = pgp(constring1);
    mydb.any('select fn_delSurveyDetails($1)', id).then((data) => {
        res.send({ "message": "Recorded Deleted...." });
    })
    pgp.end();
})

router.put('/survey/:surveyid', (req, res, next) => {

    sid = req.params.surveyid;
    sname = req.body.surveyname;
    cid = req.body.clientid;
    sdate = req.body.startingdate;
    edate = req.body.endingdate;
    sta = req.body.status;
    rwd = req.body.rewards;

    var mydb = pgp(constring1);
    mydb.any('select fn_updateSurveyDetails($1,$2,$3,$4,$5,$6,$7)',
        [sid, sname, cid, sdate, edate, sta, rwd]).then((data) => {
            res.send({ "message": "upted sucessfully...." })
        })
    pgp.end();
})

router.get('/answer', (req, res, next) => {
    var mydb = pgp(constring1)
    mydb.any("select fn_getAllAnswers()").then((data) => {
        res.send(data)
    })
    pgp.end();
})

router.post('/answer', (req, res, next) => {
    var mydb = pgp(constring1);
    console.log(req.body)
    uid = req.body.userId;
    sid = req.body.surveyId;
    qid = req.body.questionId;
    ans = req.body.answer;
    opt = req.body.option;
    mydb.any('select fn_addSurvey_answers($1,$2,$3,$4,$5)', [uid, sid, qid, ans, opt]).then((data) => {
        res.send({ 'message': 'insert successsfull' })
    })
    pgp.end();
})
router.put('/answer/:questionid', (req, res, next) => {
    ans = req.body.answer;
    qid = req.params.questionid;
    var mydb = pgp(constring1)
    mydb.any('select fn_updSurvey_answers($1,$2)', [qid, ans]).then((data) => {
        res.send({ 'message': 'updated successsfull' })
    })
    pgp.end();
})
router.delete('/answer/:questionid', (req, res, next) => {
    id = req.params.questionid
    var mydb = pgp(constring1)
    mydb.any('select  fn_delSurvey_answers($1)', id).then((data) => {
        res.send({ 'message': 'deleted' })
    })
    pgp.end();
})
router.get('/answer/:questionid', (req, res, next) => {
    id = req.params.questionid
    var mydb = pgp(constring1)
    mydb.any('select fn_getAllAnswersBy_qId($1)', id).then((data) => {
        res.send(data)
    })
    pgp.end();
})
router.get('/answer/g/:surveyid', (req, res, next) => {
    sid = req.params.surveyid
    var mydb = pgp(constring)
    mydb.any('select fn_getAllAnswersBy_sId($1)', sid).then((data) => {
        res.send(data)
    })
    pgp.end();
})
router.get('/questionsmapping', (req, res, next) => {
    var db = pgp(constring);
    db.any('select fn_selectmapping()').then((data) => {
        res.send(data)
    })
    pgp.end();
})

router.post('/questionsmapping', (req, res, next) => {

    var qid = req.body.questionId;
    var sid = req.body.surveyId;
    var db = pgp(constring);
    db.any('select fn_addmapping($1,$2)', [qid, sid]).then((data) => {
        res.send({ message: "data inserted succesfully...." })
    })
    pgp.end();
})
router.get('/product', (req, res, next) => {
    var mydb = pgp(constring1)
    mydb.any("select fn_getAllProducts()").then((data) => {
        res.send(data)
    })
    pgp.end();
})
router.post('/product', (req, res, next) => {
    var mydb = pgp(constring1);
    console.log(req.body)
    pid = req.body.productid;
    pname = req.body.productname;
    mfdate = req.body.manufacturingdate;
    expdate = req.body.expirydate;
    prc = req.body.price;
    qcode = req.body.qrcode;
    sid = req.body.surveyid;
    cid = req.body.clientid;
    pdesc = req.body.productdesc;
    brcode = req.body.barcode;
    mydb.any('select fn_addproduct($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',
        [pid, pname, mfdate, expdate, prc, qcode, sid, cid, pdesc, brcode]).then((data) => {
            res.send({ 'message': 'insert successsfull' })
        })
    pgp.end();
})
router.put('/product/:productid', (req, res, next) => {
    pid = req.params.productid;
    mfdate = req.body.manufacturingdate;
    expdate = req.body.expirydate;
    prc = req.body.price;
    pdesc = req.body.productdesc;
    var mydb = pgp(constring1)
    mydb.any('select fn_updProduct($1,$2,$3,$4,$5)', [pid, mfdate, expdate, prc, pdesc]).then((data) => {
        res.send({ 'message': 'updated successsfully' })
    })
    pgp.end();
})
router.delete('/product/:productid', (req, res, next) => {
    id = req.params.productid
    var mydb = pgp(constring1)
    mydb.any('select fn_delProduct($1)', id).then((data) => {
        res.send({ 'message': 'deleted successfully' })
    })
    pgp.end();
})
router.get('/product/:productid', (req, res, next) => {
    id = req.params.productid
    var mydb = pgp(constring1)
    mydb.any('select fn_getProductDtlsBy_pid($1)', id).then((data) => {
        res.send(data)
    })
    pgp.end();
})
router.post('/ratings', (req, res, next) => {
    var uid = req.body.userid;
    var sid = req.body.surveyid;
    var rate = req.body.rating;
    var myDb = pgp(constring1)
    myDb.any("select fn_addrating($1,$2,$3)", [uid, sid, rate]).then((data) => {
        res.send({ "message": "inserted succesfully" })
    })
    pgp.end()
})

router.get('/ratings/:surveyid', (req, res, next) => {
    var sid = req.params.surveyid;
    myDb = pgp(constring1)
    myDb.any('select fn_getratings($1)', sid).then((data) => {
        res.send(data);
    })
    pgp.end()
})

router.get('/packagemapping', (req, res, next) => {
    var db = pgp(constring);
    db.any('select fn_packagemapping()').then((data) => {
        res.send(data)
    })
    pgp.end();
})

router.post('/packagemapping', (req, res, next) => {
    var sid = req.body.surveyId;
    var pkid = req.body.pckId;
    var sta = req.body.status;

    var db = pgp(constring);
    db.any('select fn_insertmapping($1,$2,$3)', [sid, pkid, sta]).then((data) => {
        res.send({ message: "data inserted succesfully...." })
    })
    pgp.end();
})
module.exports = router