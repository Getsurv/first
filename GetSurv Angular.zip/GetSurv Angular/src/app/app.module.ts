import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'
import {HttpClientModule} from '@angular/common/http'
import {FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrtionComponent } from './registrtion/registrtion.component';
import { CarouselModule } from 'ngx-bootstrap/carousel';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AdminModule } from './admin/admin.module';
import { ClientModule } from './client/client.module';
import { UserModule } from './user/user.module';
import { AloginComponent } from './alogin/alogin.component';
import { ClientfirmComponent } from './clientfirm/clientfirm.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { ProfileComponent } from './profile/profile.component';


var myroutes: Routes = [{path: '', component: HomeComponent},
                        {path:'login', component: LoginComponent},
                       {path: 'registration', component: RegistrtionComponent},
                       {path: 'home', component: HomeComponent},
                      {path: 'aboutus', component: AboutusComponent},
                      {path: 'contactus', component: ContactusComponent},
                      {path:'alogin',component:AloginComponent},
                      {path:'cfirm',component:ClientfirmComponent},
                      {path:'cpwd',component:ChangepasswordComponent},
                      {path:'profile',component:ProfileComponent}
      ]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrtionComponent,
    HomeComponent,
    AboutusComponent,
    ContactusComponent,
    AloginComponent,
    ClientfirmComponent,
    ChangepasswordComponent,
    ProfileComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(myroutes),HttpClientModule,FormsModule,NgbModule,CarouselModule.forRoot(),
    AdminModule,
    ClientModule,
    UserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
