import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { sur } from 'src/app/models/survey';
import { SurvService } from 'src/app/services/surv.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  survey: sur
  surveyid: string
  constructor(private rt:Router,private ser:SurvService) {
    this.survey=new sur()
   }

   addQuestions(a) {
    this.rt.navigate(['add/'+a])
  }

  ngOnInit() {
    let i = localStorage.getItem('userid')
    this.ser.getSurveyByClientId(i).subscribe((data) => {
      console.log(data)
      this.survey = data
    })
  }

}
