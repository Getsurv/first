import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule, MatCheckboxModule,MatIconModule} from '@angular/material';
import 'hammerjs';


import { RouterModule, Routes } from '@angular/router'
import {HttpClientModule} from '@angular/common/http'
import {FormsModule} from '@angular/forms';
import { AddComponent } from './add/add.component';
import { SurveyComponent } from './survey/survey.component'

var nav2 : Routes = [
  {path:'chome',component:HomeComponent},
  {path:'add',component:AddComponent},
  {path:'survey',component:SurveyComponent},
  {path:'add/'+':a',component:AddComponent},
]

@NgModule({
  imports: [
    CommonModule, BrowserAnimationsModule,MatButtonModule, MatCheckboxModule,MatIconModule,
    HttpClientModule,FormsModule,RouterModule.forChild(nav2)
  ],
  declarations: [HomeComponent, AddComponent, SurveyComponent]
})
export class ClientModule { }
