import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { QuesService } from '../../services/ques.service';
import { questions, options, opts,qmodel } from '../../models/ques';
import { sur, survid } from '../../models/survey';
import { SurvService } from '../../services/surv.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  a: number                     //for option increnment
  op: opts                      //for options model
  multi: Boolean = false        //To display options template 
  sin: Boolean = false          //for hide options template
  // bool:Boolean=false            //To display true or false template
  ques: questions               //for questions model
  option: any[] = []            //options array to store values
  opt: options                  //options details model
  model: any                    //for different questions types or models
  su: sur                       //to store survey details
  count: number = 0             //To fill the symbols based on questions added
  custom: Boolean = true
  questionmodel: qmodel         //Question models or types model
  sid:string                    //to store surveyid
  constructor(private rt: Router, private ser: QuesService, private acr: ActivatedRoute, private serv: SurvService) {
    this.ques = new questions()
    this.opt = new options()
    this.op = new opts()
    this.su = new sur()
    this.questionmodel = new qmodel()
   }

   customsurvey() {
    this.custom = true
  }
  predefinedsurvey() {
    this.custom = false
  }
  btnchange(opt) {
    alert(opt)
    this.model = opt
    if (opt == 4 || opt == 5) {
      this.multi = true
      this.sin = false
      this.a = 1
    }
    else if (opt == 7) {
      this.multi = false
      this.sin = true
    }
  }
  btninc() {
    this.a++;
  }

  btnaddquestion(a, divid) {
    let i = localStorage.getItem('typeofuser')
    if (i == 'client') {
      this.ques.questiontype = "c"
    }
    else {
      this.ques.questiontype = "a"
    }
    this.ques.modelid = this.model
    let user = localStorage.getItem('userid')
    if (user == null) {
      this.ques.clientid = 'admin'
    }
    else {
      this.ques.clientid = user
    }
    this.ques.question = a
    this.option[0] = this.opt.opt1;
    this.option[1] = this.opt.opt2;
    this.option[2] = this.opt.opt3;
    this.option[3] = this.opt.opt4;
    this.option[4] = this.opt.opt5;
    this.option[5] = this.opt.opt6;
    this.option[6] = this.opt.opt7;
    this.option[7] = this.opt.opt8;
    this.option[8] = this.opt.opt9;

    var filtered = this.option.filter(function (el) {
      return el != null;
    });
    this.ques.optiondescription = filtered;
    alert(this.ques.optiondescription);
    this.ques.questionid = 1
    this.ques.surveyid=this.sid;
    this.ser.addQuestions(this.ques).subscribe((data) => {
      console.log(data)
      this.count++
    })
    //To refresh content in  a div
    // this.ngOnInit()
  }

  ngOnInit() {
    this.sid = this.acr.snapshot.params.a;
    // alert(i)
    this.serv.getSurvey(this.sid).subscribe((data) => {
      console.log(data)
      this.su = data[0]
    })
    this.ser.getQuestionModel().subscribe((data) => {
      console.log(data)
      this.questionmodel = data
    })
  }

}
