import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '../../../node_modules/@angular/router';
import { ClientService } from '../services/client.service';
import { user, firmDetails,country,state,city} from '../models/user'

import { UsersService } from '../services/users.service';

@Component({
  selector: 'app-clientfirm',
  templateUrl: './clientfirm.component.html',
  styleUrls: ['./clientfirm.component.css']
})
export class ClientfirmComponent implements OnInit {
  c:city
  co:country
  s:state
  countryid:any
  reg: user
  firm: firmDetails
  constructor(private acr:ActivatedRoute,private ser:ClientService,private rt:Router,private us:UsersService) {
    this.reg = new user()
    this.firm = new firmDetails()
    this.co=new country()
    this.s=new state()
    this.c=new city()
   }

   btnfunction(frm) {
    if (frm.valid) {
      this.firm.firstname = this.reg.firstname
      this.firm.lastname = this.reg.lastname
      this.firm.emailid = this.reg.emailid
      this.firm.password = this.reg.password
      this.firm.mobileno = this.reg.mobileno
      this.firm.gender = this.reg.gender
      this.firm.address = this.reg.address
      this.firm.country = this.reg.country
      this.firm.state = this.reg.state
      this.firm.city = this.reg.city
      this.firm.zipcode = this.reg.zipcode
      this.firm.typeofuser = this.reg.typeofuser
      this.firm.image = this.reg.image
      this.firm.firmname = frm.value.firmname;
      this.firm.establishedyear = frm.value.establishedyear;
      this.firm.description = frm.value.description;
      this.firm.parentfirm = frm.value.parentfirm;
      this.firm.faddress = frm.value.faddress;
      this.firm.fcountry = frm.value.fcountry;
      this.firm.fstate = frm.value.fstate;
      this.firm.fcity = frm.value.fcity;
      this.firm.fzipcode = frm.value.fzipcode;
      alert(JSON.stringify(this.firm))
      this.ser.clientregister(this.firm).subscribe((data) => {
        console.log(data)
      })
      this.rt.navigate(['login'])
    }
  }

  getStates(c) {
    this.countryid = c
    alert(c)
    this.us.getstatedetails(c).subscribe((data) => {
      console.log(data)
      this.s = data;
    })
  }
  getCity(c) {
    alert(c)
    this.us.getcitydetials(this.countryid, c).subscribe((data) => {
      console.log(data)
      this.c = data
    })
  }

  ngOnInit() {
    this.acr.queryParams.subscribe(params => {
      this.reg.typeofuser = params["typeofuser"];
      this.reg.firstname = params["firstname"];
      this.reg.lastname = params["lastname"];
      this.reg.gender = params["gender"];
      this.reg.emailid = params["emailid"];
      this.reg.image = params["image"];
      this.reg.mobileno = params["mobileno"];
      this.reg.password = params["password"];
      this.reg.address = params["address"];
      this.reg.city = params["city"];
      this.reg.country = params["country"];
      this.reg.state = params["state"];
      this.reg.zipcode = params["zipcode"];
      alert(JSON.stringify(this.reg))
    });
    this.us.getcountrydetails().subscribe((data) => {
      console.log(data)
      this.co = data
    })
  }

}
