import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientfirmComponent } from './clientfirm.component';

describe('ClientfirmComponent', () => {
  let component: ClientfirmComponent;
  let fixture: ComponentFixture<ClientfirmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientfirmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
