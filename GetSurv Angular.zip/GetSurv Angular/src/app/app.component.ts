import { Component, OnInit, DoCheck } from '@angular/core';
import { Observable , of} from '../../node_modules/rxjs';
import { Router } from '../../node_modules/@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,DoCheck {
  title = 'SurveyApp';

  us : Observable <string>;
  cl : Observable <string>;
  ad : Observable <string> ;
typeof : any

constructor (private rt: Router){

}

ngOnInit(){

}

checkLocalstorage() : Observable <any>  {
  return of(localStorage.getItem('typeofuser'));
} 

checkLocalstorage2() : Observable <any>  {
return of(localStorage.getItem('username'));
}

ngDoCheck(){
  this.checkLocalstorage().subscribe((data)=>{
    this.typeof = data;
    if(this.typeof == 'user'){
      this.us = data;
    }
    else if( this.typeof == 'client'){
      this.cl = data;
    }
  })

  this.checkLocalstorage2().subscribe((data)=>{
    this.ad = data;
  })
}

btnlogout(){
  localStorage.clear();  
  this.rt.navigate(['login'])
  location.reload()
}

}
