import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http'
import { alogin } from'../models/admin'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  url : string  =  "http://localhost:4500/as/"
  constructor( private htc: HttpClient) {

   }

   CheckLogin(u: string, p : string) : Observable<any>{
    return this.htc.get(this.url+'adm' +'/'+u+'/'+p,{responseType:'json'})
  }
}
