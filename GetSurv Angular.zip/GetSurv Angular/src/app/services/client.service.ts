import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import { user,firmDetails} from '../models/user'

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  url: string = "http://localhost:4500/cs"
 
 
  constructor( private htc:HttpClient) { 

  }
  clientregister(us: firmDetails): Observable<any> {
    console.log(JSON.stringify(us));
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.url + '/user'  , JSON.stringify(us), httpOptions)
  }
}
