import { Component, OnInit } from '@angular/core';
import { UsersService } from '../../services/users.service';
import { user ,survey ,img,  trsurvey} from '../../models/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  details: user
  list : any
  imag:img
  surveydetails :survey
  surveycount:survey
  test : trsurvey
  survies:string="Trending Surveys"
  constructor(private us:UsersService,private rt:Router) {
    this.details = new user();
    this.surveydetails=new survey();
    this.surveycount=new survey();
    this.imag=new img()
    this.test = new trsurvey()
   }

   getProfile(email){
      this.rt.navigate(['profile'])
   }
   changepwd(email){
     this.rt.navigate(['cpwd'])
   }

   img(event) {
    if (event.target.files && event.target.files[0]) {
      let rdr = new FileReader();
      rdr.readAsDataURL(event.target.files[0])
      rdr.onload = (ev: any) => {
        this.imag.image = ev.target.result
      
        this.imag.image = this.imag.image.replace("data:image/jpeg;base64,", "")
        this.imag.image = this.imag.image.replace("data:image/jpg;base64,", "")
        this.imag.image = this.imag.image.replace("data:image/png;base64,", "")
        this.imag.image = this.imag.image.replace("data:image/gif;base64,", "")
        this.imag.uid = localStorage.getItem('userid')
        alert(this.imag.image)
        this.us.UpdateImg(this.imag).subscribe((data) => {
          this.list = data
        })
        location.reload();
      }
    }
  }

  trend(){
    this.us.trendingSurveys().subscribe((data)=>{
      this.test = data
      this.survies="Trending Surveys"
      console.log(data)
    })
  }
  ongoing(){
    this.us.ongoingsurveys().subscribe((data)=>{
      this.test=data
      this.survies="OngGoing Surveys"
      console.log(data)
    })
  }
  upcoming(){
    this.us.Getupcmgsurvey().subscribe((data)=>{
      this.test = data
      this.survies="UpComing Surveys"
      console.log(data)
    })
  }
  completed(){
    this.us.getcompletedsurvey().subscribe((data)=>{
      this.test = data
      this.survies="Completed Surveys"
      console.log(data)
    })
  }


  ngOnInit() {
    this.details.emailid = localStorage.getItem('emailid')
    this.us.GetByEmail(this.details.emailid).subscribe((data)=>{ this.list = data

      this.details.firstname =data[0].firstname
      this.details.lastname = data[0].lastname
      this.details.emailid = data[0].emailid
      this.details.userid = data[0].userid
      this.details.mobileno = data[0].mobileno
      this.details.gender = data[0].gender
      this.details.country =  data[0].country
      this.details.state =  data[0].state
      this.details.city = data[0].city
      this.details.address =  data[0].address
      this.details.zipcode = data[0].zipcode
      this.details.typeofuser =   data[0].typeofuser
      this.details.image = data[0].image;

      this.us.Getrewardpoints(this.details.userid).subscribe((data)=>{
        this.list=data
        console.log(data)
       if(data[0].reward==null){
         this.surveydetails.rewards="0" ;
       }
       else
       {
         this.surveydetails.rewards=data[0].reward;
       }
     })
     this.us.Getsurveycount(this.details.userid).subscribe((data)=>{ this.list=data
       this.surveycount.surveycou=data[0].surveid
       console.log(this.surveycount.surveycou)
     })
    })

    this.us.trendingSurveys().subscribe((data)=>{
      this.test = data
      console.log(data)
    })

}
}
