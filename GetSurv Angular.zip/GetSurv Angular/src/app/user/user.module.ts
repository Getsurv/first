import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';

import { RouterModule, Routes } from '@angular/router'
import {HttpClientModule} from '@angular/common/http'
import {FormsModule} from '@angular/forms';
import { FeedbackComponent } from './feedback/feedback.component'

var nav3 : Routes = [
  {path:'uhome',component:HomeComponent},
  {path:'feedback',component:FeedbackComponent}
]

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,FormsModule,RouterModule.forChild(nav3)
  ],
  declarations: [HomeComponent, FeedbackComponent]
})
export class UserModule { }
