export class alogin{
    username:string;
     password:string;
    
    }