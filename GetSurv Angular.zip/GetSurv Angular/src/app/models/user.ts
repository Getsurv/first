export class user {
    firstname: string;
    lastname: string;
    emailid: string;
    password: string;
    mobileno: number;
    gender: string;
    address: string;
    country: string;
    state: string;
    city: string;
    zipcode: number;
    typeofuser: string;
    image: string;
    userid: string;
}

export class login{
    emailid:string
    password:string
}

export class firmDetails {
    firstname: string;
    lastname: string;
    emailid: string;
    password: string;
    mobileno: number;
    gender: string;
    address: string;
    country: string;
    state: string;
    city: string;
    zipcode: number;
    typeofuser: string;
    image: string;
    userid: string;
    firmname: string;
    establishedyear: Date;
    description: string;
    parentfirm: string;
    faddress: string;
    fcity: string;
    fstate: string;
    fcountry: string;
    fzipcode: number;
}

export class feedback{
    name:string;
    emailid:string;
    rating:string;
    review:string;
}

export class country{
    id:number;
    sortnumber:string;
    name:string;
    phonecode:number;
}
export class state{
    id:number;
    name:string;
    countryid:number;
}
export class city{
    id:number;
    name:string;
    stateid:number;
}

export class survey{
    rewards:string;
    surveycou:string;
}
export class img{
    image:string
    uid:string
}


export class trsurvey {
    surveyid:string;
    surveyname:string;
    rewards:number;
    image : string
}
