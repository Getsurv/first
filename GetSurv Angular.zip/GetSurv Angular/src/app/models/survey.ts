export class sur{
    surveyname:string;
    clientid:string;
    image:string;
    status:string;
    rewards:number;
    startingdate:Date;
    endingdate:Date;
}

export class survid{
    surveyid:string;
}