export class questions {
    question: string;
    clientid: string;
    questiontype: string;
    modelid: number;
    questionid: number;
    optiondescription: string[] = [];
    surveyid:string;
}
export class options {
    opt1: string;
    opt2: string;
    opt3: string;
    opt4: string;
    opt5: string;
    opt6: string;
    opt7: string;
    opt8: string;
    opt9: string;
}
export class opts {
    questionid: number;
    optiondescription: string[] = [];
}
export class qmodel{
    modelid:number;
    modeltype:string;
}