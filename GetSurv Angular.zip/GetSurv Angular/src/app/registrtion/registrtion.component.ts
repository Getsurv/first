import { UsersService } from './../services/users.service';
import { Component, OnInit } from '@angular/core';
import { Router,NavigationExtras } from '../../../node_modules/@angular/router';
import { user,country,state,city} from '../models/user'
import { ClientService } from '../services/client.service';

@Component({
  selector: 'app-registrtion',
  templateUrl: './registrtion.component.html',
  styleUrls: ['./registrtion.component.css']
})
export class RegistrtionComponent implements OnInit {
  c:city
  co:country
  s:state
  countryid:any
  frmvalid:Boolean=false
  regis:user
  type:string
  constructor(private rt:Router,private ser:UsersService) { 
    this.regis=new user()
    this.co=new country()
    this.s=new state()
    this.c=new city()
  }

  btnuser(frm) {
    if (frm.valid) {
      this.regis.image = this.regis.image.replace("data:image/jpeg;base64,", "")
      this.regis.image = this.regis.image.replace("data:image/jpg;base64,", "")
      this.regis.image = this.regis.image.replace("data:image/png;base64,", "")
      this.regis.image = this.regis.image.replace("data:image/gif;base64,", "")
      this.regis.firstname = frm.value.firstname
      this.regis.lastname = frm.value.lastname
      this.regis.emailid = frm.value.emailid
      this.regis.password = frm.value.password
      this.regis.mobileno = frm.value.mobileno
      this.regis.gender = frm.value.gender
      this.regis.address = frm.value.address
      this.regis.country = frm.value.country
      this.regis.state = frm.value.state
      this.regis.city = frm.value.city
      this.regis.zipcode = frm.value.zipcode
      this.regis.typeofuser = "user"
      alert(JSON.stringify(this.regis))
      this.ser.register(this.regis).subscribe((data) => {
        console.log(data)
      })
      this.rt.navigate(['login'])
    }
  }

  btnclient(frm: any) {
    if (frm.valid) {
      this.regis.image = this.regis.image.replace("data:image/jpeg;base64,", "")
      this.regis.image = this.regis.image.replace("data:image/jpg;base64,", "")
      this.regis.image = this.regis.image.replace("data:image/png;base64,", "")
      this.regis.image = this.regis.image.replace("data:image/gif;base64,", "")
      this.regis.firstname = frm.value.firstname
      this.regis.lastname = frm.value.lastname
      this.regis.emailid = frm.value.emailid
      this.regis.password = frm.value.password
      this.regis.mobileno = frm.value.mobileno
      this.regis.gender = frm.value.gender
      this.regis.address = frm.value.address
      this.regis.country = frm.value.country
      this.regis.state = frm.value.state
      this.regis.city = frm.value.city
      this.regis.zipcode = frm.value.zipcode
      this.regis.typeofuser = "client"
      let i: NavigationExtras = {
        queryParams: this.regis
      };
      this.rt.navigate(['cfirm'], i)
    }
  }
  onFileSelect(event) {

    if (event.target.files && event.target.files[0]) {
      let rdr = new FileReader();
      rdr.readAsDataURL(event.target.files[0])
      rdr.onload = (ev: any) => {
        this.regis.image = ev.target.result
      }
    }
    console.log(this.regis.image)
  }

  btnfunction(frm){
    if(frm.valid){
      this.frmvalid=true
    }
    else{
      alert("please fill the details")
    }
  }

  getStates(c){
    this.countryid=c
   // alert(c)
    this.ser.getstatedetails(c).subscribe((data)=>{
      console.log(data)
      this.s=data;
    })
  }
  getCity(c){
   // alert(c)
    this.ser.getcitydetials(this.countryid,c).subscribe((data)=>{
      console.log(data)
     this.c=data
  //    alert(JSON.stringify(data))
   })
  }



  ngOnInit() {
    this.ser.getcountrydetails().subscribe((data)=>{
      console.log(data)
      this.co=data
    })
  }

}
