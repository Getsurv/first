import { AdminService } from './../services/admin.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { alogin } from '../models/admin'

@Component({
  selector: 'app-alogin',
  templateUrl: './alogin.component.html',
  styleUrls: ['./alogin.component.css']
})
export class AloginComponent implements OnInit {
  login : alogin
  constructor( private as: AdminService,private rt: Router) {
    this.login = new alogin()
   }

  ngOnInit() {
  }

  loginform(username,password,ngx){
    if(ngx.valid){
      let u = username.value;
      let p = password.value;
      alert ( u + '  ' +p)
     this.as.CheckLogin(u,p).subscribe((data) => {
         if (data.length > 0) {
             localStorage.setItem("username",u)
             this.rt.navigate(['ahome'])
             alert('Hi Admin')
         }
         else {
             alert('Invalid Admin Credentials..')
         }
     })
    }
    else{
      alert('Enter details')
    }
  
}

}
