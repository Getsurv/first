import { UsersService } from './../services/users.service';
import { Component, OnInit } from '@angular/core';
import { login } from '../models/user'
import { Router } from '../../../node_modules/@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  reg: login;
  constructor(private rt : Router,private lg: UsersService) { 
    this.reg = new login();
  }

  btnclick(userid, password, myfrm) {
    if(myfrm.valid){
    var u = userid.value;
    var p = password.value;
     // alert( u + '  ' +p)
    this.lg.userlogin(u, p).subscribe((data) => {
      this.reg = data;
      console.log(data)
      
      if (data.length > 0) {
        let x = data[0].userid
        let y = data[0].typeofuser;
     alert(x + ' ' +y)
        alert('Login Success')
       localStorage.setItem('emailid',u); 
        localStorage.setItem('userid',x);
       localStorage.setItem('typeofuser',y);
           if( y == 'user'){
             this.rt.navigate(['uhome'])
           }
           else if(y == 'client') {
             this.rt.navigate(['chome'])
           }
      }
     else {
       alert('Invalid user')
     }
    })
  }
else
{
  alert('enter details....')
}
}

fnsignup() {
  this.rt.navigate(['registration'])
}

fnforgetpass(){
  this.rt.navigate([''])
}

  ngOnInit() {
  }

}
