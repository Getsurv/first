import { Component, OnInit } from '@angular/core';
import { UsersService } from '../services/users.service';
import { user } from '../models/user';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
details : user
list : any
  constructor(private us:UsersService) { 
    this.details = new user();
  }

  ngOnInit() {
    this.details.emailid = localStorage.getItem('emailid')
    this.us.GetByEmail(this.details.emailid).subscribe((data)=>{ this.list = data

      this.details.firstname =data[0].firstname
      this.details.lastname = data[0].lastname
      this.details.emailid = data[0].emailid
      this.details.userid = data[0].userid
      this.details.mobileno = data[0].mobileno
      this.details.gender = data[0].gender
      this.details.country =  data[0].country
      this.details.state =  data[0].state
      this.details.city = data[0].city
      this.details.address =  data[0].address
      this.details.zipcode = data[0].zipcode
      this.details.typeofuser =   data[0].typeofuser
      this.details.image = data[0].image;
    })

  }

}
